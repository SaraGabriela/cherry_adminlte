<?php
declare(strict_types=1);

namespace App\Test\TestCase\Model\Table;

use App\Model\Table\RecipeProductMeasuresTable;
use Cake\ORM\TableRegistry;
use Cake\TestSuite\TestCase;

/**
 * App\Model\Table\RecipeProductMeasuresTable Test Case
 */
class RecipeProductMeasuresTableTest extends TestCase
{
    /**
     * Test subject
     *
     * @var \App\Model\Table\RecipeProductMeasuresTable
     */
    protected $RecipeProductMeasures;

    /**
     * Fixtures
     *
     * @var array
     */
    protected $fixtures = [
        'app.RecipeProductMeasures',
        'app.RawProducts',
        'app.RawRecipes',
    ];

    /**
     * setUp method
     *
     * @return void
     */
    public function setUp(): void
    {
        parent::setUp();
        $config = TableRegistry::getTableLocator()->exists('RecipeProductMeasures') ? [] : ['className' => RecipeProductMeasuresTable::class];
        $this->RecipeProductMeasures = TableRegistry::getTableLocator()->get('RecipeProductMeasures', $config);
    }

    /**
     * tearDown method
     *
     * @return void
     */
    public function tearDown(): void
    {
        unset($this->RecipeProductMeasures);

        parent::tearDown();
    }

    /**
     * Test validationDefault method
     *
     * @return void
     */
    public function testValidationDefault(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildRules method
     *
     * @return void
     */
    public function testBuildRules(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
