<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Equivalence $equivalence
 */
?>
<div class="row">
    <aside class="column">
        <div class="side-nav">
            <h4 class="heading"><?= __('Actions') ?></h4>
            <?= $this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', $equivalence->id],
                ['confirm' => __('Are you sure you want to delete # {0}?', $equivalence->id), 'class' => 'side-nav-item']
            ) ?>
            <?= $this->Html->link(__('List Equivalences'), ['action' => 'index'], ['class' => 'side-nav-item']) ?>
        </div>
    </aside>
    <div class="column-responsive column-80">
        <div class="equivalences form content">
            <?= $this->Form->create($equivalence) ?>
            <fieldset>
                <legend><?= __('Edit Equivalence') ?></legend>
                <?php
                    echo $this->Form->control('description');
                ?>
            </fieldset>
            <?= $this->Form->button(__('Submit')) ?>
            <?= $this->Form->end() ?>
        </div>
    </div>
</div>
